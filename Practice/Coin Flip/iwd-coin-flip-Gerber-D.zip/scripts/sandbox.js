var selection_click = function (id) {

    guessMade(id);
}